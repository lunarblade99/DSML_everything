def add(a, b):
	return a + b

def subtract(a, b):
	return a - b

def main():
	print("Welcome to maths library")

if __name__ == "__main__":
	main()
