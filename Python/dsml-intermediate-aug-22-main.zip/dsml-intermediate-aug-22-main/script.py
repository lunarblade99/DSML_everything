import math

def main():
	print(math)

if __name__ == "__main__":
	main()
